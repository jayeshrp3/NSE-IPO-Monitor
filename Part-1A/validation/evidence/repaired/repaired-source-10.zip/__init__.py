"""Server-rendered web routes."""
