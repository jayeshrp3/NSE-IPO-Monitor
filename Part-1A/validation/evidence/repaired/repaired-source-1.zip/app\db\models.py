"""IPO persistence record representation."""

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class IPORecord:
    id: int
    company_name: str
    opening_date: str
    closing_date: str
    allotment_date: str | None
    refund_date: str | None
    listing_date: str | None
    created_at: str
    updated_at: str

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> "IPORecord":
        return cls(
            id=int(row["id"]),
            company_name=str(row["company_name"]),
            opening_date=str(row["opening_date"]),
            closing_date=str(row["closing_date"]),
            allotment_date=row["allotment_date"],
            refund_date=row["refund_date"],
            listing_date=row["listing_date"],
            created_at=str(row["created_at"]),
            updated_at=str(row["updated_at"]),
        )
