"""Independent date-boundary, listing weekday, and threshold checks."""

from datetime import date, timedelta


def payload(company_name, opening, closing, listing=None):
    return {
        "company_name": company_name,
        "opening_date": opening.isoformat(),
        "closing_date": closing.isoformat(),
        "listing_date": listing.isoformat() if listing else None,
    }


def create_record(client, company_name, opening, closing, listing=None):
    response = client.post(
        "/api/ipos",
        json=payload(company_name, opening, closing, listing),
    )
    assert response.status_code == 201, response.text
    return response.json()


def test_status_opening_closing_listing_and_expiry_boundaries(client):
    today = date.today()
    upcoming = create_record(
        client,
        "Upcoming boundary",
        today + timedelta(days=1),
        today + timedelta(days=4),
    )
    opening_boundary = create_record(client, "Opening boundary", today, today)
    expired = create_record(
        client,
        "Expired boundary",
        today - timedelta(days=5),
        today - timedelta(days=1),
    )

    closing = today - timedelta(days=10)
    minimum_listing = closing
    counted = 0
    while counted < 3:
        minimum_listing += timedelta(days=1)
        if minimum_listing.weekday() < 5:
            counted += 1
    listed = create_record(
        client,
        "Listing boundary",
        closing - timedelta(days=3),
        closing,
        minimum_listing,
    )

    assert upcoming["status"] == "Upcoming"
    assert opening_boundary["status"] == "Open"
    assert opening_boundary["days_remaining"] == 0
    assert expired["status"] == "Closed"
    assert expired["days_remaining"] == -1
    assert expired["expired_days"] == 1
    assert expired["alert_status"] == "Expired"
    assert listed["status"] == "Listed"


def test_listing_date_requires_three_weekdays_not_calendar_days(client):
    closing = date(2026, 1, 9)  # Friday
    accepted = create_record(
        client,
        "Weekday listing accepted",
        closing - timedelta(days=2),
        closing,
        date(2026, 1, 14),  # Wednesday; Tuesday is the second weekday
    )
    assert accepted["listing_date"] == "2026-01-14"

    rejected = client.post(
        "/api/ipos",
        json=payload(
            "Weekday listing rejected",
            closing - timedelta(days=1),
            closing,
            date(2026, 1, 13),
        ),
    )
    assert rejected.status_code == 422
    assert "three weekdays" in rejected.json()["detail"]


def test_alert_threshold_is_inclusive_and_only_for_open_records(client):
    today = date.today()
    at_threshold = create_record(
        client,
        "At threshold",
        today - timedelta(days=1),
        today + timedelta(days=3),
    )
    beyond_threshold = create_record(
        client,
        "Beyond threshold",
        today - timedelta(days=1),
        today + timedelta(days=4),
    )
    assert at_threshold["status"] == "Open"
    assert at_threshold["days_remaining"] == 3
    assert at_threshold["alert_status"] == "Approaching"
    assert beyond_threshold["status"] == "Open"
    assert beyond_threshold["alert_status"] == "None"
