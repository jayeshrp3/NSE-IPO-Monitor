"""IPO duplicate identity policy."""

from datetime import date

from app.db.models import IPORecord
from app.utils.normalization import normalize_company_name


def is_duplicate(
    existing: IPORecord,
    company_name: str,
    opening_date: date,
    closing_date: date,
    *,
    exclude_id: int | None = None,
) -> bool:
    return (
        existing.id != exclude_id
        and normalize_company_name(existing.company_name) == normalize_company_name(company_name)
        and existing.opening_date == opening_date.isoformat()
        and existing.closing_date == closing_date.isoformat()
    )
