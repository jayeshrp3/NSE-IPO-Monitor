"""Browser-visible page and explicit deletion-confirmation tests."""

from datetime import date, timedelta


def test_pages_load_and_delete_cancel_sends_no_request(browser, base_url):
    page = browser.new_page()
    response = page.goto(f"{base_url}/")
    assert response is not None and response.status == 200
    assert page.get_by_role("heading", name="IPO schedule").is_visible()
    assert page.locator('link[href*="/static/css/styles.css"]').count() == 1
    assert page.locator('script[src*="/static/js/app.js"]').count() == 1

    form_page = page.goto(f"{base_url}/ipos/new")
    assert form_page is not None and form_page.status == 200
    assert page.get_by_role("heading", name="Add IPO").is_visible()

    created = page.request.post(
        f"{base_url}/api/ipos",
        data={
            "company_name": "Confirm deletion",
            "opening_date": (date.today() + timedelta(days=10)).isoformat(),
            "closing_date": (date.today() + timedelta(days=12)).isoformat(),
        },
    )
    assert created.status == 201
    record = created.json()
    detail = page.goto(f"{base_url}/ipos/{record['id']}")
    assert detail is not None and detail.status == 200
    assert page.get_by_role("heading", name="Confirm deletion").is_visible()

    delete_requests = []
    page.on(
        "request",
        lambda request: delete_requests.append(request.url)
        if request.method == "DELETE"
        else None,
    )
    page.on("dialog", lambda dialog: dialog.dismiss())
    page.get_by_role("button", name="Delete").click()
    assert delete_requests == []
    assert page.request.get(f"{base_url}/api/ipos/{record['id']}").status == 200
    page.close()


def test_delete_confirmation_accepts_and_deletes(browser, base_url):
    page = browser.new_page()
    created = page.request.post(
        f"{base_url}/api/ipos",
        data={
            "company_name": "Confirmed deletion",
            "opening_date": (date.today() + timedelta(days=20)).isoformat(),
            "closing_date": (date.today() + timedelta(days=22)).isoformat(),
        },
    )
    assert created.status == 201
    record_id = created.json()["id"]
    page.on("dialog", lambda dialog: dialog.accept())
    page.goto(f"{base_url}/ipos/{record_id}")
    page.get_by_role("button", name="Delete").click()
    page.wait_for_url(f"{base_url}/")
    assert page.request.get(f"{base_url}/api/ipos/{record_id}").status == 404
    page.close()
