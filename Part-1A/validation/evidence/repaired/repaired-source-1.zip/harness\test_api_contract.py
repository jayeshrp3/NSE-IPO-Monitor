"""Public HTTP contract checks; application modules are intentionally not imported."""


def test_list_contract_and_static_assets(client):
    response = client.get("/api/ipos")
    assert response.status_code == 200
    assert response.json() == []

    stylesheet = client.get("/static/css/styles.css")
    script = client.get("/static/js/app.js")
    assert stylesheet.status_code == 200
    assert "text/css" in stylesheet.headers["content-type"]
    assert script.status_code == 200
    assert "javascript" in script.headers["content-type"]


def test_missing_record_and_request_validation_contract(client):
    assert client.get("/api/ipos/999999").status_code == 404

    response = client.post(
        "/api/ipos",
        json={
            "company_name": "Contract IPO",
            "opening_date": "2026-02-30",
            "closing_date": "2026-03-01",
        },
    )
    assert response.status_code == 422
    assert response.json()["detail"]
