"""Company-name normalization used by duplicate detection."""

import re


def normalize_company_name(company_name: str) -> str:
    """Trim, collapse whitespace, and case-fold a company name."""
    return re.sub(r"\s+", " ", company_name.strip()).casefold()
