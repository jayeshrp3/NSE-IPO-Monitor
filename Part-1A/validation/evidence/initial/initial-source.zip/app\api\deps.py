"""FastAPI dependencies."""

from fastapi import Request

from app.services.ipo_service import IPOService
from app.db.repository import IPORepository


def get_ipo_service(request: Request) -> IPOService:
    settings = request.app.state.settings
    return IPOService(IPORepository(settings), settings)
