"""Exercise safe behavior when persisted IPO content is corrupted."""

import sqlite3

from datetime import date, timedelta


def test_corrupt_persisted_date_surfaces_safe_error_without_rewrite(
    client, base_url, database_path
):
    assert base_url.startswith("http://127.0.0.1:")

    response = client.post(
        "/api/ipos",
        json={
            "company_name": "Corruption target",
            "opening_date": (date.today() + timedelta(days=1)).isoformat(),
            "closing_date": (date.today() + timedelta(days=3)).isoformat(),
        },
    )
    assert response.status_code == 201
    record_id = response.json()["id"]

    with sqlite3.connect(database_path) as connection:
        connection.execute("PRAGMA ignore_check_constraints = ON")
        connection.execute(
            "UPDATE ipos SET closing_date = ? WHERE id = ?",
            ("not-a-date", record_id),
        )

    corrupted = client.get(f"/api/ipos/{record_id}")
    assert corrupted.status_code == 500
    assert "invalid closing_date" in corrupted.json()["detail"]
    with sqlite3.connect(database_path) as connection:
        saved_value = connection.execute(
            "SELECT closing_date FROM ipos WHERE id = ?", (record_id,)
        ).fetchone()[0]
    assert saved_value == "not-a-date"
