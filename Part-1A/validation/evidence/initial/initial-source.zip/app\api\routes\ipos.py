"""IPO JSON API."""

from typing import Annotated

from fastapi import APIRouter, Depends, Query, Response, status

from app.api.deps import get_ipo_service
from app.core.errors import IPOError
from app.schemas.ipo import IPOCreate, IPOUpdate
from app.services.ipo_service import IPOService

router = APIRouter(prefix="/api/ipos", tags=["ipos"])
ServiceDependency = Annotated[IPOService, Depends(get_ipo_service)]


@router.post("", status_code=status.HTTP_201_CREATED)
def create_ipo(payload: IPOCreate, service: ServiceDependency) -> dict:
    return service.create(payload.model_dump())


@router.get("")
def list_ipos(
    service: ServiceDependency,
    company_name: str | None = Query(default=None),
    status_filter: str | None = Query(default=None, alias="status"),
    sort: str = Query(default="opening_date"),
    order: str = Query(default="asc"),
) -> list[dict]:
    return service.list(
        company_name=company_name,
        status=status_filter,
        sort=sort,
        order=order,
    )


@router.get("/{ipo_id}")
def get_ipo(ipo_id: int, service: ServiceDependency) -> dict:
    result = service.get(ipo_id)
    if result is None:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="IPO record not found.")
    return result


@router.put("/{ipo_id}")
def update_ipo(ipo_id: int, payload: IPOUpdate, service: ServiceDependency) -> dict:
    result = service.update(ipo_id, payload.model_dump(), payload.model_fields_set)
    if result is None:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="IPO record not found.")
    return result


@router.delete("/{ipo_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_ipo(ipo_id: int, service: ServiceDependency) -> Response:
    if not service.delete(ipo_id):
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="IPO record not found.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
